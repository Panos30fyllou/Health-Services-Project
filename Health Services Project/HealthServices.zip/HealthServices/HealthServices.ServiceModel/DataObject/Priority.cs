﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HealthServices.ServiceModel.DataObject
{
    public enum Priority
    {
        Low = 1,
        Normal = 2,
        High = 3,
        Urgent = 4
    }
}
