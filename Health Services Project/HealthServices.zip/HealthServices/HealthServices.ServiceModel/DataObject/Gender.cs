﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HealthServices.ServiceModel.DataObject
{
    public enum Gender
    {
        Man = 1,
        Woman = 2
    }
}
